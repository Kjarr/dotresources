#!/usr/bin/env bash
rofi -dmenu\
    -i\
    -no-fixed-num-lines\
    -p "Are You Sure? : "\
    -theme ~/.config/rofi/power/confirm.rasi
